-- https://github.com/nvim-mini/mini.nvim
return {
  { "nvim-mini/mini.nvim", version = false },
}
